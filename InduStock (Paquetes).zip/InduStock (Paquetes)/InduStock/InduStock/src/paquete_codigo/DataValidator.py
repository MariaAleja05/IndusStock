# DataValidator.py

import datetime
from datetime import datetime                   # Provides classes for working with dates and times in Python.

class DataValidator:
    def __init__(self):
        pass                # This class does not perform any actions

    def no_spaces(self, text):
        # Check if there is at least one space in the text
        if ' ' in text:
            return False  
        else:
            return True   

    def max_length(self, text, length):
        # Check if the length of the provided text does not exceed the specified length
        text_length = len(text)  # Get the length of the text
        if text_length <= length:
            return True  
        else:
            return False 

    # Function to check if the provided text can be converted to a float
    def is_float(self, text):
        # Check if the provided text can be converted to a float
        if text == "-":
            return True
        try:
            # Try to convert the text to a float
            float_value = float(text)
            return True
        except ValueError:
            return False

    # Function to check if the provided text can be converted to an integer
    def is_integer(self, text):
        # Check if the provided text can be converted to an integer
        try:
            int(text)
            return True
        except ValueError:
            return False
        
    def is_valid_date(self, date_text):
        # Check if the length of date_text is 10 characters and format is 'dd/mm/yyyy'
        if date_text == "-/-/-":
            return True
        
        if len(date_text) != 10 or date_text[2] != '/' or date_text[5] != '/':
            return False

        # Extract day, month, and year parts from the date_text
        day_str = date_text[:2]
        month_str = date_text[3:5]
        year_str = date_text[6:]

        # Check if day, month, and year are all numeric
        if not (day_str.isdigit() and month_str.isdigit() and year_str.isdigit()):
            return False

        day = int(day_str)
        month = int(month_str)
        year = int(year_str)

        try:
            # Attempt to create a datetime object with the provided date
            datetime(year, month, day)
            return True
        except ValueError:
            return False
    
    def validate_id_nit(self, id_nit):
            if not self.no_spaces(id_nit):
                return "El ID NIT no debe contener espacios."
            return None

    def validate_nombre_proveedor(self, nombre):
        if not self.max_length(nombre, 25):
            return "El Nombre del Proveedor no debe exceder 25 caracteres."
        return None

    def validate_codigo(self, codigo):
        if not self.no_spaces(codigo):
            return "El Código no debe contener espacios."
        return None

    def validate_nombre_producto(self, nombre):
        if not self.max_length(nombre, 50):
            return "El Nombre del Producto no debe exceder 50 caracteres."
        return None

    def validate_cantidad(self, cantidad):
        if not self.is_integer(cantidad):
            return "La Cantidad debe ser un número entero."
        return None
    
    def validate_medida(self, medida):
        
        if not self.is_float(medida) :
            return "La medida debe ser un número"
        return None
   
    def validate_precio(self, precio):
        try:
            # Attempting to convert the price to a floating number
            float(precio)
            return None
        except ValueError:
            return "El Precio debe ser un número."

    def validate_fecha_vencimiento(self, fecha):
        if not self.is_valid_date(fecha):
            return "La Fecha de Vencimiento no es válida. Use el formato dd/mm/yyyy."
        return None
