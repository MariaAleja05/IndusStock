# MainWindow

import tkinter as tk                            # Used to create GUI
from tkinter import Toplevel                    # 
from tkinter import ttk, messagebox as mssg     # Provides a set of widgets, display dialog boxes, 
import sqlite3                                  # Python library for interacting with SQLite databases
import datetime
from datetime import datetime                   # Provides classes for working with dates and times in Python.
from .DataValidator import DataValidator
from .DataBaseBuild import DataBaseBuild

class MainWindow:
    def __init__(self, window):
        self.wind = window
        self.wind.title("Sistema de Inventario")
        self.wind.geometry('1000x700')
        self.wind.resizable(False, False)
       
        # Initialize Database and Validator
        self.db = DataBaseBuild()
        self.validator = DataValidator()

        # Set up the UI
        self.setup_GUI()

        # Populate initial data
        self.get_productos()

    def setup_GUI(self):
        frame = tk.LabelFrame(self.wind, text="Registrar Nuevo Producto")
        frame.grid(row=0, column=0, padx=20, pady=10)

    # Labels and Entries
        tk.Label(frame, text="ID NIT:").grid(row=0, column=0, pady=5, padx=5, sticky='e')
        self.id_nit = tk.Entry(frame)
        self.id_nit.grid(row=0, column=1, pady=5, padx=5)
        #self.id_nit.bind("<FocusOut>", self.validate_id_nit)

        tk.Label(frame, text="Nombre Proveedor:").grid(row=1, column=0, pady=5, padx=5, sticky='e')
        self.nombre_proveedor = tk.Entry(frame)
        self.nombre_proveedor.grid(row=1, column=1, pady=5, padx=5)
        #self.nombre_proveedor.bind("<FocusOut>", self.validate_nombre_proveedor)

        tk.Label(frame, text="Código Producto:").grid(row=3, column=0, pady=5, padx=5, sticky='e')
        self.codigo = tk.Entry(frame)
        self.codigo.grid(row=3, column=1, pady=5, padx=5)
        #self.codigo.bind("<FocusOut>", self.validate_codigo)

        tk.Label(frame, text="Nombre Producto:").grid(row=4, column=0, pady=5, padx=5, sticky='e')
        self.nombre_producto = tk.Entry(frame)
        self.nombre_producto.grid(row=4, column=1, pady=5, padx=5)
        #self.nombre_producto.bind("<FocusOut>", self.validate_nombre_producto)

        tk.Label(frame, text="""Medida:\nSi no aplica ingrese: "-" """).grid(row=5, column=0, pady=5, padx=5, sticky='e')
        self.medida = tk.Entry(frame)
        self.medida.grid(row=5, column=1, pady=5, padx=5)
        #self.medida.bind("<FocusOut>", self.validate_medida)

        tk.Label(frame, text="Cantidad:").grid(row=6, column=0, pady=5, padx=5, sticky='e')
        self.cantidad = tk.Entry(frame)
        self.cantidad.grid(row=6, column=1, pady=5, padx=5)
        #self.cantidad.bind("<FocusOut>", self.validate_cantidad)

        tk.Label(frame, text="Precio:").grid(row=7, column=0, pady=5, padx=5, sticky='e')
        self.precio = tk.Entry(frame)
        self.precio.grid(row=7, column=1, pady=5, padx=5)
        #self.precio.bind("<FocusOut>", self.validate_precio)

        tk.Label(frame, text="""Fecha Vencimiento (dd/mm/yyyy):\n Si no aplica ingrese: "-/-/-" """).grid(row=8, column=0, pady=5, padx=5, sticky='e')
        self.fecha_vencimiento = tk.Entry(frame)
        self.fecha_vencimiento.grid(row=8, column=1, pady=5, padx=5)
        self.fecha_vencimiento.insert(0, 'dd/mm/yyyy')
        self.fecha_vencimiento.bind("<FocusIn>", lambda e: self.fecha_vencimiento.delete(0, tk.END))
        #self.fecha_vencimiento.bind("<FocusOut>", self.validate_fecha_vencimiento)

    # Campo para la Fecha de Registro
        tk.Label(frame, text="Fecha Registro (dd/mm/yyyy):").grid(row=9, column=0, pady=5, padx=5, sticky='e')
    
    # Obtener la fecha actual en formato dd/mm/yyyy
        fecha_hoy = datetime.now().strftime("%d/%m/%Y")
    
        self.fecha_registro = tk.Entry(frame)
        self.fecha_registro.grid(row=9, column=1, pady=5, padx=5)
    
    # Insertar la fecha actual automáticamente
        self.fecha_registro.insert(0, fecha_hoy)

        ttk.Button(frame, text="Guardar Producto", command=self.add_producto).grid(row=10, column=0, pady=10, padx=5)
        ttk.Button(frame, text="Actualizar Producto", command=self.update_producto).grid(row=10, column=1, pady=10, padx=5)
        ttk.Button(frame, text="Retirar Productos", command=self.retirar_productos).grid(row=11, column=0, pady=10, padx=5)
        ttk.Button(frame, text="Eliminar Producto", command=self.delete_producto).grid(row=11, column=1, pady=10, padx=5)
        ttk.Button(frame, text="Limpiar Campos", command=self.clear_fields).grid(row=12, column=0, pady=10, padx=5)
        ttk.Button(frame, text="Mirar Base de Datos", command=self.open_db_window).grid(row=12, column=1, pady=10, padx=5)
        ttk.Button(frame, text="Ver Retiros", command=self.mostrar_modificaciones).grid(row=13, column=0, pady=10, padx=5)
      
        # Treeview
        
        self.tree = ttk.Treeview(self.wind, columns=("IdNit", "Proveedor", "Codigo", "Nombre", "Medida", "Cantidad", "Precio", "FechaVencimiento","FechaRegistro"), show='headings')
        self.tree.heading("IdNit", text="ID NIT")
        self.tree.heading("Proveedor", text="Proveedor")
        self.tree.heading("Codigo", text="Código")
        self.tree.heading("Nombre", text="Nombre")
        self.tree.heading("Medida", text="Medida gr/l")
        self.tree.heading("Cantidad", text="Cantidad")
        self.tree.heading("Precio", text="Precio")
        self.tree.heading("FechaVencimiento", text="F/Vencimiento")
        self.tree.heading("FechaRegistro", text="F/Registro")
        self.tree.column("IdNit", width=80)
        self.tree.column("Proveedor", width=120)
        self.tree.column("Codigo", width=80)
        self.tree.column("Nombre", width=120)
        self.tree.column("Medida", width=80)
        self.tree.column("Cantidad", width=80)
        self.tree.column("Precio", width=80)
        self.tree.column("FechaVencimiento", width=100)
        self.tree.heading("FechaRegistro", text="F/Registro")
        self.tree.grid(row=1, column=0, columnspan=2, padx=20, pady=10)
        self.tree.bind("<Double-1>", self.on_double_click)
    
    def mostrar_modificaciones(self):
    # Crear una ventana nueva para mostrar las modificaciones
        ventana_modificaciones = Toplevel()
        ventana_modificaciones.title("Historial de Modificaciones")

    # Crear una tabla (treeview) para mostrar los datos
        tree = ttk.Treeview(ventana_modificaciones, columns=("Codigo", "Cantidad", "Fecha"), show="headings")
        tree.heading("Codigo", text="Código Producto")
        tree.heading("Cantidad", text="Cantidad Retirada")
        tree.heading("Fecha", text="Fecha de Retiro")

    # Conectarse a la base de datos y obtener los registros de la tabla Modificaciones
        with sqlite3.connect(self.db.db_name) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT Codigo_producto, Cantidad_retirada, Fecha_retiro FROM Modificaciones")
            for row in cursor.fetchall():
                tree.insert("", "end", values=row)

    # Mostrar la tabla
        tree.pack(fill=tk.BOTH, expand=True)

        def validate_id_nit(self, event):
            error_message = self.validator.validate_id_nit(self.id_nit.get())
            if error_message:
                mssg.showerror("Error", error_message)
                self.id_nit.focus_set()
                return False
            return True
   
    def validate_id_nit(self, event):
        error_message = self.validator.validate_id_nit(self.id_nit.get())
        if error_message:
            mssg.showerror("Error", error_message)
            self.id_nit.focus_set()
            return False
        return True
    
    def validate_nombre_proveedor(self, event):
        error_message = self.validator.validate_nombre_proveedor(self.nombre_proveedor.get())
        if error_message:
            mssg.showerror("Error", error_message)
            self.nombre_proveedor.focus_set()
            return False
        return True

    def validate_codigo(self, event):
        error_message = self.validator.validate_codigo(self.codigo.get())
        if error_message:
            mssg.showerror("Error", error_message)
            self.codigo.focus_set()
            return False
        return True

    def validate_nombre_producto(self, event):
        error_message = self.validator.validate_nombre_producto(self.nombre_producto.get())
        if error_message:
            mssg.showerror("Error", error_message)
            self.nombre_producto.focus_set()
            return False
        return True

    def validate_medida(self, event):
        error_message = self.validator.validate_medida(self.medida.get())
        if error_message:
            mssg.showerror("Error", error_message)
            self.medida.focus_set()
            return False
        return True

    def validate_cantidad(self, event):
        error_message = self.validator.validate_cantidad(self.cantidad.get())
        if error_message:
            mssg.showerror("Error", error_message)
            self.cantidad.focus_set()
            return False
        return True

    def validate_precio(self, event):
        error_message = self.validator.validate_precio(self.precio.get())
        if error_message:
            mssg.showerror("Error", error_message)
            self.precio.focus_set()
            return False
        return True

    def validate_fecha_vencimiento(self, event):
        error_message = self.validator.validate_fecha_vencimiento(self.fecha_vencimiento.get())
        if error_message:
            mssg.showerror("Error", error_message)
            self.fecha_vencimiento.focus_set()
            return False
        return True

    # Methods with the DataBase
    
    def open_db_window(self):
    # Crear una nueva ventana
        new_window = Toplevel(self.wind)
        new_window.title("Base de Datos")
        new_window.geometry("800x700")

    # Asignar un manejador de eventos para que el Treeview sea destruido correctamente al cerrar la ventana
        def on_close():
        # Destruye la ventana secundaria y limpia los widgets asociados
            new_window.destroy()

        new_window.protocol("WM_DELETE_WINDOW", on_close)  # Configurar el cierre correcto de la ventana

    # Etiquetas y campos de entrada para las fechas
        tk.Label(new_window, text="Fecha Inicio (DD-MM-YYYY):").pack(pady=5)                                  
        start_date_entry = tk.Entry(new_window)
        start_date_entry.pack(pady=5)

        tk.Label(new_window, text="Fecha Fin (DD-MM-YYYY):").pack(pady=5)
        end_date_entry = tk.Entry(new_window)
        end_date_entry.pack(pady=5)

        search_button = tk.Button(new_window, text="Buscar Productos", 
                                command=lambda: self.search_products(new_window, start_date_entry.get(), end_date_entry.get()))
        search_button.pack(pady=10)

    # Tabla para mostrar resultados
        self.tree_db_window = ttk.Treeview(new_window, columns=("ID NIT", "Proveedor", "Medida gr/l", "Cantidad", "Precio", "F/Vencimiento", "F/Registro"), show='headings')

    # Definir encabezados y anchos de columnas
        self.tree_db_window.heading("ID NIT", text="ID NIT")
        self.tree_db_window.heading("Proveedor", text="Proveedor")
        self.tree_db_window.heading("Medida gr/l", text="Medida gr/l")
        self.tree_db_window.heading("Cantidad", text="Cantidad")
        self.tree_db_window.heading("Precio", text="Precio")
        self.tree_db_window.heading("F/Vencimiento", text="F/Vencimiento")
        self.tree_db_window.heading("F/Registro", text="F/Registro")

    # Establecer anchos de columnas
        self.tree_db_window.column("ID NIT", width=100)
        self.tree_db_window.column("Proveedor", width=150)
        self.tree_db_window.column("Medida gr/l", width=100)
        self.tree_db_window.column("Cantidad", width=100)
        self.tree_db_window.column("Precio", width=100)
        self.tree_db_window.column("F/Vencimiento", width=120)
        self.tree_db_window.column("F/Registro", width=120)

        self.tree_db_window.pack(fill="both", expand=True, pady=20)
    
    def search_products(self, window, start_date, end_date):
        validator = DataValidator()

    # Verificar que las fechas tengan el formato correcto usando la función is_valid_date
        if not validator.is_valid_date(start_date) or not validator.is_valid_date(end_date):
            mssg.showerror("Error", "Por favor ingresa las fechas en formato DD/MM/YYYY.")
            return

        try:
        # Convertir las fechas al formato adecuado
            start_date_obj = datetime.strptime(start_date, '%d/%m/%Y')
            end_date_obj = datetime.strptime(end_date, '%d/%m/%Y')

        # Conectar a la base de datos y ejecutar la consulta
            conn = sqlite3.connect(self.db.db_name)
            cursor = conn.cursor()

            query = """
            SELECT IdNit, Proveedor, Medida, Cantidad, Precio, FechaVencimiento, FechaRegistro
            FROM Productos
            WHERE FechaRegistro BETWEEN ? AND ?
            """
            cursor.execute(query, (start_date, end_date))
            productos = cursor.fetchall()
            conn.close()

        # Limpiar la tabla antes de insertar nuevos resultados
            for row in self.tree_db_window.get_children():
                self.tree_db_window.delete(row)

        # Insertar los productos en el Treeview si están dentro del rango de fechas
            for producto in productos:
                self.tree_db_window.insert("", "end", values=producto)

        except sqlite3.Error as e:
            mssg.showerror("Error", f"Error al conectarse a la base de datos: {e}")
        except ValueError:
            mssg.showerror("Error", "Las fechas no tienen el formato correcto.")

    def get_productos(self):
        # Limpiar la tabla antes de actualizarla
        records = self.tree.get_children()  # Obtener todos los registros actuales del treeview
        for element in records:
            self.tree.delete(element)  # Eliminar cada registro

        # Obtener productos desde la base de datos
        productos = self.db.get_productos()  # Consulta a la base de datos
        productos = productos.fetchall()  # Asegurarse de obtener todos los registros como una lista

        if productos:  # Si hay productos en la base de datos
            for row in productos:
                # Insertar los productos en la tabla de la interfaz gráfica (treeview)
                self.tree.insert('', tk.END, values=row)
        else:
            print("No hay productos para mostrar.")  # Para depuración en caso de que no haya productos
    
    def add_producto(self):
    # Validar todos los campos aquí, no en FocusOut
        if not self.validate_all_fields():
            return  # Si algo no pasa la validación, detener la ejecución
    
        try:
            self.db.insert_producto(
                self.id_nit.get(),
                self.nombre_proveedor.get(),
                self.codigo.get(),
                self.nombre_producto.get(),
                self.medida.get(),
                int(self.cantidad.get()),
                float(self.precio.get()),
                self.fecha_vencimiento.get(),
                self.fecha_registro.get()
            )
            self.get_productos()
            self.clear_fields()

        except sqlite3.IntegrityError as e:
            mssg.showerror("Error", f"Error al agregar el producto: {e}")

    def update_producto(self):
        if not self.validate_all_fields():
            return  # Si algo no pasa la validación, detener la ejecución
    
        try:
            self.db.update_producto(
                self.codigo.get(),
                self.nombre_producto.get(),
                self.medida.get(),
                int(self.cantidad.get()),
                float(self.precio.get()),
                self.fecha_vencimiento.get(),
                self.fecha_registro.get()
            )
            self.get_productos()
            self.clear_fields()
            mssg.showinfo("Éxito", "Producto actualizado correctamente.")
    
        except ValueError:
            mssg.showerror("Error", "La cantidad debe ser un número entero y el precio debe ser un número decimal.")
    
    def validate_all_fields(self):
    # Llamar a todas las funciones de validación y mostrar errores
        if self.validator.validate_id_nit(self.id_nit.get()):
            mssg.showerror("Error", self.validator.validate_id_nit(self.id_nit.get()))
            return False
    
        if self.validator.validate_nombre_proveedor(self.nombre_proveedor.get()):
            mssg.showerror("Error", self.validator.validate_nombre_proveedor(self.nombre_proveedor.get()))
            return False

        if self.validator.validate_codigo(self.codigo.get()):
            mssg.showerror("Error", self.validator.validate_codigo(self.codigo.get()))
            return False

        if self.validator.validate_nombre_producto(self.nombre_producto.get()):
            mssg.showerror("Error", self.validator.validate_nombre_producto(self.nombre_producto.get()))
            return False

        if self.validator.validate_medida(self.medida.get()):
            mssg.showerror("Error", self.validator.validate_medida(self.medida.get()))
            return False

        if self.validator.validate_cantidad(self.cantidad.get()):
            mssg.showerror("Error", self.validator.validate_cantidad(self.cantidad.get()))
            return False

        if self.validator.validate_precio(self.precio.get()):
            mssg.showerror("Error", self.validator.validate_precio(self.precio.get()))
            return False

        if self.validator.validate_fecha_vencimiento(self.fecha_vencimiento.get()):
            mssg.showerror("Error", self.validator.validate_fecha_vencimiento(self.fecha_vencimiento.get()))
            return False

        return True  # Si todo pasa la validación
    
    def retirar_productos(self):
        id_nit = self.id_nit.get()
        cantidad_retirar = self.cantidad.get()  # Usar self.cantidad para obtener la cantidad

        if self.validate_id_nit(None) and self.validate_cantidad(None):
        # Buscar productos asociados al ID NIT
            productos = self.db.get_productos_by_nit(id_nit)

            if productos:
                for producto in productos:
                    current_cantidad = producto[5]  # Cantidad actual del producto (producto[5] es la cantidad)
                    try:
                        nueva_cantidad = int(cantidad_retirar)
                        if nueva_cantidad <= current_cantidad:
                        # Actualizar la cantidad en la base de datos usando la nueva función
                            filas_afectadas = self.db.modifica_cantidad(
                                producto[2],  # Código del producto (producto[2] es el código)
                                current_cantidad - nueva_cantidad  # Nueva cantidad
                            )
                        
                            if filas_afectadas > 0:
                            # Registrar el retiro en la tabla Modificaciones
                                self.db.registrar_retiro(producto[2], nueva_cantidad)
                            
                            # Mostrar mensaje de éxito si se actualizó correctamente
                                mssg.showinfo("Éxito", "Productos retirados correctamente.")
                            
                            # Refrescar la lista de productos en la interfaz gráfica
                                self.get_productos()  # Esto actualiza la GUI con los datos más recientes
                            
                            # Limpiar los campos de entrada
                                self.clear_fields()
                                break  # Salir del bucle después de actualizar un producto
                            else:
                                mssg.showerror("Error", "No se pudo actualizar el producto en la base de datos.")
                                break
                        else:
                            mssg.showerror("Error", f"No hay suficiente cantidad de {producto[3]} en inventario.")  # producto[3] es el nombre del producto
                            break  # Salir del bucle si no hay suficiente cantidad
                    except ValueError:
                        mssg.showerror("Error", "La cantidad debe ser un número entero.")
                        break  # Salir del bucle si la cantidad no es válida
            else:
            # No hay productos asociados al ID NIT
                mssg.showerror("Error", "No se encontraron productos asociados al ID NIT.")
        else:
        # No se ingresó ID NIT o la cantidad no es válida
            mssg.showerror("Error", "Por favor, ingrese el ID NIT y la cantidad a retirar.")

    def delete_producto(self):
    # Obtener el código del producto desde el campo de entrada
        codigo = self.codigo.get()

        if codigo:  # Verificar que se haya ingresado un código
            confirmar = mssg.askyesno("Confirmación", f"¿Estás seguro de que deseas eliminar el producto con código {codigo}?")
        
            if confirmar:
                try:
                # Llamar a la función de la base de datos para eliminar el producto
                    self.db.delete_producto(codigo)
                
                # Refrescar el Treeview después de eliminar el producto
                    self.get_productos()  # Esto actualiza el Treeview con los productos restantes
                
                # Limpiar los campos de entrada
                    self.clear_fields()

                # Mostrar un mensaje de éxito
                    mssg.showinfo("Éxito", f"Producto con código {codigo} eliminado correctamente.")

                except Exception as e:
                    mssg.showerror("Error", f"Error al eliminar el producto: {e}")
        else:
            mssg.showerror("Error", "Debes ingresar el código del producto a eliminar.")

    def on_double_click(self, event):
    # Verifica si el widget treeview existe
        if not self.tree.exists(self.tree.selection()):
            mssg.showerror("Error", "No se puede seleccionar el elemento. El Treeview ya no está disponible.")
            return

        try:
        # Obtener el ítem seleccionado desde el treeview
            selected_item = self.tree.selection()[0]
            values = self.tree.item(selected_item, 'values')

        # Limpiar los campos de entrada
            self.clear_fields()

        # Poner los valores seleccionados en los campos
            self.id_nit.insert(0, values[0])
            self.nombre_proveedor.insert(0, values[1])
            self.codigo.insert(0, values[2])
            self.nombre_producto.insert(0, values[3])
            self.medida.insert(0, values[4])
            self.cantidad.insert(0, values[5])
            self.precio.insert(0, values[6])
            self.fecha_vencimiento.insert(0, values[7])
            self.fecha_registro.insert(0, values[8])

        # Buscar y mostrar detalles del proveedor asociado
            proveedor = self.db.search_proveedor(values[0]).fetchone()
            if proveedor:
                self.nombre_proveedor.insert(0, proveedor[1])

        except IndexError:
            mssg.showerror("Error", "Error al seleccionar el producto.")
        except Exception as e:
            mssg.showerror("Error", f"Ocurrió un error: {e}")
    
    def clear_fields(self):
        self.id_nit.delete(0, tk.END)
        self.nombre_proveedor.delete(0, tk.END)
        self.codigo.delete(0, tk.END)
        self.nombre_producto.delete(0, tk.END)
        self.medida.delete(0, tk.END)
        self.cantidad.delete(0, tk.END)
        self.precio.delete(0, tk.END)
        self.fecha_vencimiento.delete(0, tk.END)
        self.fecha_vencimiento.insert(0, 'dd/mm/yyyy')
        self.fecha_registro.delete(0, tk.END)
        self.fecha_registro.insert(0, 'dd/mm/yyyy')
        
        fecha_hoy = datetime.now().strftime("%d/%m/%Y")

        self.fecha_registro.delete(0, tk.END)
        self.fecha_registro.insert(0, fecha_hoy)

    def validate_all_fields(self):
        return (
            self.validate_id_nit(None) and
            self.validate_nombre_proveedor(None) and
            self.validate_codigo(None) and
            self.validate_nombre_producto(None) and
            self.validate_medida(None) and
            self.validate_cantidad(None) and
            self.validate_precio(None) and
            self.validate_fecha_vencimiento(None)
        )
   