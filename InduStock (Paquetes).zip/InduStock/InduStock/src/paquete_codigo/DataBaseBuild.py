# DataBaseBuild.py

import tkinter as tk                            # Used to create GUI
from tkinter import Toplevel                    # 
from tkinter import ttk, messagebox as mssg     # Provides a set of widgets, display dialog boxes, 
import sqlite3                                  # Python library for interacting with SQLite databases
import datetime
from datetime import datetime                   # Provides classes for working with dates and times in Python.

class DataBaseBuild:
    def __init__(self):
        # Name of the database file
        self.db_name = 'manejo-inventario.db'
        # Create the database file if it doesn't exist
        self.database_build()
    
    def database_build(self):  
        # Establish a connection to the database 
        with sqlite3.connect(self.db_name) as conn:
            
            # In order to interact with the database.
            cursor = conn.cursor()
            
            #Execute an SQL query to create 'Modificaiones' table if it does not exist
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS Modificaciones (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    Codigo_producto TEXT NOT NULL,
                    Cantidad_retirada INTEGER NOT NULL,
                    Fecha_retiro DATE NOT NULL,
                    FOREIGN KEY (Codigo_producto) REFERENCES Productos(IdNit)
                
                )
            """)
            
            # Execute an SQL query to create the 'Productos' table if it does not exist.
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS Productos (
                    IdNit TEXT,
                    Proveedor TEXT,
                    Codigo TEXT PRIMARY KEY,
                    Nombre TEXT,
                    Medida INTEGER,
                    Cantidad INTEGER,
                    Precio REAL,
                    FechaVencimiento TEXT,
                    FechaRegistro TEXT,
                    FOREIGN KEY(IdNit) REFERENCES Proveedores(IdNit)
                )
            """)
            
            # Commit the changes made to the database.
            conn.commit()

    def registrar_retiro(self, codigo_producto, cantidad_retirada):
    # Establecer la conexión a la base de datos
        with sqlite3.connect(self.db_name) as conn:
            cursor = conn.cursor()

        # Registrar la fecha y hora actual del retiro
            fecha_retiro = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        # Insertar los datos en la tabla Modificaciones
            cursor.execute("""
                INSERT INTO Modificaciones (Codigo_producto, Cantidad_retirada, Fecha_retiro)
                VALUES (?, ?, ?)
            """, (codigo_producto, cantidad_retirada, fecha_retiro))

        # Confirmar los cambios
            conn.commit()
    
    def run_query(self, query, parameters=()):
        # Open a connection to the SQLite database 
        with sqlite3.connect(self.db_name) as conn:
            # Create a cursor 
            cursor = conn.cursor()
            
            # Execute the SQL query with the provided parameters
            # query: SELECT, INSERT, UPDATE, DELETE. The action
            # parameters: the values
            result = cursor.execute(query, parameters)
            
            # Commit the transaction to save changes to the database (e.g., INSERT, UPDATE, DELETE)
            conn.commit()
        
        # Return the result of the executed query
        return result

    # Product operations

    def insert_producto(self, id_nit, proovedor, codigo, nombre, medida, cantidad, precio, fecha_vencimiento,fecha_registro=datetime.now()):
        query = 'INSERT INTO Productos VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
        parameters = (id_nit, proovedor, codigo, nombre, medida, cantidad, precio, fecha_vencimiento, fecha_registro)
        self.run_query(query, parameters)

    def get_productos(self):
        query = 'SELECT * FROM Productos'
        return self.run_query(query)

    def update_producto(self, codigo, nombre, medida, cantidad, precio, fecha_vencimiento, fecha_registro):
    # Consulta SQL para actualizar el producto
        query = '''
            UPDATE Productos 
            SET Nombre = ?, Medida = ?, Cantidad = ?, Precio = ?, FechaVencimiento = ?, FechaRegistro = ?
            WHERE Codigo = ?
        '''
        parameters = (nombre, medida, cantidad, precio, fecha_vencimiento, fecha_registro, codigo)

    # Establecer conexión a la base de datos
        with sqlite3.connect(self.db_name) as conn:
            cursor = conn.cursor()
            cursor.execute(query, parameters)

        # Verificar cuántas filas fueron afectadas
            filas_afectadas = cursor.rowcount
            print(f"Filas afectadas por la actualización: {filas_afectadas}")

        # Confirmar la transacción
            conn.commit()

        return filas_afectadas

    def delete_producto(self, codigo):
        query = 'DELETE FROM Productos WHERE Codigo = ?'
        self.run_query(query, (codigo,))

    def search_producto(self, codigo):
        query = 'SELECT * FROM Productos WHERE Codigo = ?'
        return self.run_query(query, (codigo,))

    def get_productos_by_proveedor(self, id_nit):
        query = 'SELECT * FROM Productos WHERE IdNit = ?'
        return self.run_query(query, (id_nit,))

    def get_productos_by_proveedor_nombre(self, nombre_proveedor):
        # Ejecuta una consulta para obtener productos según el nombre del proveedor
        query = """
        SELECT * FROM Productos
        WHERE IdNit IN (
            SELECT IdNit FROM Proveedores WHERE Nombre = ?
        )
        """
        return self.run_query(query, (nombre_proveedor,))

    def search_proveedor_por_nombre(self, nombre_proveedor):
        # Ejecuta una consulta para obtener detalles del proveedor por nombre
        query = """
        SELECT * FROM Proveedores
        WHERE Nombre = ?
        """
        return self.run_query(query, (nombre_proveedor,))
    
    def get_cantidad_by_id_nit(self, id_nit):
        query = 'SELECT * FROM Productos WHERE IdNit = ?'
        result = self.run_query(query, (id_nit,))
        # Fetch all products associated with the given IdNit
        productos = result.fetchall()  # Return all matching products as a list
        return productos if productos else None  # Return the list or None if no products are found

    def get_productos_by_nit(self, id_nit):
        query = 'SELECT * FROM Productos WHERE IdNit = ?'
        result = self.run_query(query, (id_nit,))
        return result.fetchall()  # Devuelve todos los productos asociados al ID NIT

    def modifica_cantidad(self, codigo, nueva_cantidad):
        # Abre una conexión a la base de datos
        with sqlite3.connect(self.db_name) as conn:
            # Crear un cursor para ejecutar la consulta
            cur = conn.cursor()

            # Consulta SQL para actualizar la cantidad del producto
            sql = '''
                UPDATE Productos
                SET Cantidad = ?
                WHERE Codigo = ?
            '''
            
            # Ejecutar la consulta con los parámetros correspondientes
            cur.execute(sql, (nueva_cantidad, codigo))

            # Obtener el número de filas afectadas
            n = cur.rowcount

            # Confirmar los cambios (commit ya está implícito con el 'with')
            conn.commit()

            # Cerrar el cursor (esto es automático al salir del 'with')

            # Devolver el número de filas afectadas
            return n
